import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {

        Connection connection = null;

        try {
            connection = DriverManager
                    .getConnection("jdbc:mysql://localhost:3306/education_plus", "root", "1423");

            System.out.println("You are in!");

        } catch (Exception ex) {
            System.out.println("Not connected!");
        }


        PreparedStatement stmt =
                connection.prepareStatement("INSERT INTO `companies` (`username`, `password`, `name`, `town`)\n" +
                        "VALUES (\n" +
                        "'qwerty', '12345678', 'education', 'ruse'\n" +
                        ");");

//        PreparedStatement stmt =
//                connection.prepareStatement("DELETE FROM `companies` WHERE `id` = 1;");

        stmt.execute();


    }
}
