
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


public class Application {

    @SpringBootApplication
    public class EducationPlusApplication {

        public static void main(String[] args) {
            SpringApplication.run(EducationPlusApplication.class, args);
        }
    }
}