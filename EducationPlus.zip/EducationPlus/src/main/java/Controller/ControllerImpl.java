package Controller;

import Subjects.Company;
import Subjects.Person;
import Subjects.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ControllerImpl {
    private List<User> users;
    private List<Person> persons;
    private List<Company> companies;

    public ControllerImpl() {
        this.users = new ArrayList<>();
        this.persons = new ArrayList<>();
        this.companies = new ArrayList<>();
    }

    @GetMapping("/")
    public ModelAndView index(ModelAndView modelAndView) {
        modelAndView.setViewName("index");
        modelAndView.addObject("users", this.users);
        return modelAndView;
    }

    @PostMapping("/")
    public String add(User user) {
        this.users.add(user);

        return "redirect:/";
    }

    @PutMapping("/")
    public String updateByName(User changedUser) {
        for (User user : users) {
            if (user.getUsername().equals(changedUser.getUsername())) {
                this.users.remove(user);
                this.users.add(changedUser);

                break;
            }
        }
        return "redirect:/";
    }
}
