package Events;

public class FreeTime extends EventImpl implements EventInterface {

    public FreeTime(String name) {
        super(name);
    }
}
