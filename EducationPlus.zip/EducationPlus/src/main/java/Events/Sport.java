package Events;

public class Sport extends EventImpl implements EventInterface {

    public Sport(String name) {
        super(name);
    }
}
