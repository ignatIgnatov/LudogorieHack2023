package Events;

public class Work extends EventImpl implements EventInterface {

    public Work(String name) {
        super(name);
    }
}
