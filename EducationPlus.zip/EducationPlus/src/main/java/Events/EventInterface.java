package Events;

public interface EventInterface {

    String getType();
    String getDescription();

}
