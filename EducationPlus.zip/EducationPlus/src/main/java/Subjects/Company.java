package Subjects;

public interface Company {

    String getName();
    String getTown();
    String getDescription();

}
