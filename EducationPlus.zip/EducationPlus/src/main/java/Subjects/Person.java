package Subjects;

import org.hibernate.validator.constraints.NotEmpty;

import java.util.List;

public interface Person {

    String getFirstName();
    String getLastName();
    int getAge();
    String getGender();
    String getTown();
    String getStatus();
    String getEducation();
    List<String> getHobbiesAndInterests();

}
